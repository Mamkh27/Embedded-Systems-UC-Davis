//*****************************************************************************
//
// Application Name     - int_sw
// Application Overview - The objective of this application is to demonstrate
//                          GPIO interrupts using SW2 and SW3.
//                          NOTE: the switches are not debounced!
//
//*****************************************************************************

//****************************************************************************
//
//! \addtogroup int_sw
//! @{
//
//****************************************************************************

// Standard includes
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Driverlib includes
#include "hw_types.h"
#include "hw_ints.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "interrupt.h"
#include "hw_apps_rcm.h"
#include "prcm.h"
#include "rom.h"
#include "rom_map.h"
#include "prcm.h"
#include "gpio.h"
#include "utils.h"
#include "timer.h"

// Common interface includes
#include "uart_if.h"
#include "uart.h"
#include "spi.h"
#include "Adafruit_GFX.h"
#include "Adafruit_SSD1351.h"
#include "glcdfont.h"
#include "test.h"
#include "pin_mux_config.h"

#define SPI_IF_BIT_RATE  100000

#define CONSOLE1              UARTA1_BASE
#define CONSOLE1_PERIPH  PRCM_UARTA1
#define UartGetChar()        MAP_UARTCharGet(CONSOLE1)
#define UartPutChar(c)       MAP_UARTCharPut(CONSOLE1,c)
#define MAX_STRING_LENGTH    80
//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************
extern void (* const g_pfnVectors[])(void);

volatile unsigned long pin61_intcount;
volatile unsigned char pin61_intflag;

volatile unsigned long temp;
unsigned long buffer[1000]; // buffer to store IR Data

static volatile unsigned long g_ulBase;
unsigned long g_ulTimerInts;
int gpioTimeCount;
int buttCount;
char gpioArr[26] = "";
char letter = ' ';
char letterArr[80] = "";
int numButtPress;
int tempTwo;
int matchFound;
int num;
int numColor;
int color;
int enter;
int UART_flag;
char cChar;
char cBuf[256];
char cCharacter;

const char * ZERO = "111111100010000000011101";
const char * ONE = "111111000100000000111011";
const char * TWO = "111111100100000000011011";
const char * THREE = "111111010100000000101011";
const char * FOUR = "111111110100000000001011";
const char * FIVE = "111111001100000000110011";
const char * SIX  = "111111101100000000010011";
const char * SEVEN = "111111011100000000100011";
const char * EIGHT = "111111111100000000000011";
const char * NINE  = "111111000010000000111101";
const char * MUTE  = "111111101000000000010111";
const char * LAST  = "111111001000000000110111";
const char * POWER= "111111100000000000011111";
const char * UP   = "111111010101000000101010";
const char * LEFT = "111111001101000000110010";
const char * DOWN = "111111110101000000001010";
const char * RIGHT= "111111101101000000010010";
const char * MENU = "111111110110000000001001";
const char * OK   = "111111110001000000001110";

//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************

// an example of how you can use structs to organize your pin settings for easier maintenance
typedef struct PinSetting {
    unsigned long port;
    unsigned int pin;
} PinSetting;

static PinSetting pin61 = { .port = GPIOA0_BASE, .pin = 0x40};

//*****************************************************************************
//                      LOCAL FUNCTION PROTOTYPES
//*****************************************************************************
static void BoardInit(void);

//*****************************************************************************
//                      LOCAL FUNCTION DEFINITIONS
//*****************************************************************************
static void GPIOA0IntHandler(void) { // PIN61 handler
    unsigned long ulStatus;
    char str;

    ulStatus = MAP_GPIOIntStatus (pin61.port, true);
    MAP_GPIOIntClear(pin61.port, ulStatus);        // clear interrupts on GPIOA1
    pin61_intcount++;
    pin61_intflag=1;

    gpioTimeCount = g_ulTimerInts;

    if(gpioTimeCount > 2 && gpioTimeCount <= 5){
        gpioTimeCount = 1;
        str = '1';
    }
    else if(gpioTimeCount <3){
        gpioTimeCount = 0;
        str = '0';
    }
    else{
        str = '-';
    }

    if(strlen(gpioArr) < 26){
        strncat(gpioArr, &str, 1);
    }

    g_ulTimerInts = 0;
}

void
TimerBaseIntHandler(void)
{
    //
    // Clear the timer interrupt.
    //
    Timer_IF_InterruptClear(g_ulBase);

    g_ulTimerInts ++;
}

//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************

void
UART1Handler(){
    UART_flag = 1;
    UARTIntClear(CONSOLE1,UART_INT_RX);

//    int UARTDataCount = 0;
//    cChar = MAP_UARTCharGetNonBlocking(CONSOLE);
//   // cChar = MAP_UARTCharGetNonBlocking(UART1_BASE);
//
//    //store data while not end of string
//    while((cChar != '\0'))
//    {
//        cBuf[UARTDataCount] = cChar;
//        UARTDataCount++;
//    }

}

void
initAdafruit(){
    //
    // Enable the SPI module clock
    //
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI,PRCM_RUN_MODE_CLK);
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI,PRCM_RUN_MODE_CLK);
    MAP_PRCMPeripheralReset(PRCM_GSPI);
    MAP_SPIReset(GSPI_BASE);
    MAP_SPIConfigSetExpClk(GSPI_BASE,MAP_PRCMPeripheralClockGet(PRCM_GSPI),
                           SPI_IF_BIT_RATE,SPI_MODE_MASTER,SPI_SUB_MODE_0,
                           (SPI_SW_CTRL_CS |
                                   SPI_4PIN_MODE |
                                   SPI_TURBO_OFF |
                                   SPI_CS_ACTIVEHIGH |
                                   SPI_WL_8));

    MAP_SPIEnable(GSPI_BASE);
    Adafruit_Init();
}

static void
BoardInit(void) {
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);

    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}

//***************************************************************************
//
//! Main function
//!
//! \param none
//!
//!
//! \return None.
//
//****************************************************************************
int main() {
    unsigned long ulStatus;

    BoardInit();

    PinMuxConfig();

    InitTerm();

    MAP_UARTConfigSetExpClk(CONSOLE1,MAP_PRCMPeripheralClockGet(CONSOLE1_PERIPH),
                      UART_BAUD_RATE, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
                       UART_CONFIG_PAR_NONE));

    ClearTerm();

    initAdafruit();

    //
    // Register the interrupt handlers
    //
    MAP_GPIOIntRegister(pin61.port, GPIOA0IntHandler);
    MAP_UARTIntRegister(CONSOLE1, UART1Handler); // UART INTERRUPT

    //
    // Configure rising edge interrupts on pin61
    //
    MAP_GPIOIntTypeSet(pin61.port, pin61.pin, GPIO_RISING_EDGE);    // pin61

    ulStatus = MAP_GPIOIntStatus (pin61.port, false);
    MAP_GPIOIntClear(pin61.port, ulStatus);            // clear interrupts on GPIOA1

    //
    // Base address for first timer
    //
    g_ulBase = TIMERA0_BASE;

    //
    // Configuring the timers
    //
    Timer_IF_Init(PRCM_TIMERA0, g_ulBase, TIMER_CFG_PERIODIC, TIMER_A, 0);

    //
    // Setup the interrupts for the timer timeouts.
    //
    Timer_IF_IntSetup(g_ulBase, TIMER_A, TimerBaseIntHandler);

    //
    // Turn on the timers feeding values in mSec
    //
    Timer_IF_Start(g_ulBase, TIMER_A, 1);

    // clear global variables
    pin61_intcount=0;
    pin61_intflag=0;
    gpioTimeCount = 0;
    numButtPress = 0;
    buttCount = 0;
    matchFound = 0;
    num = 0;
    numColor = 0;
    enter = 0;
    color = GREEN;

    // pin61 interrupts
    UARTEnable(CONSOLE1);
    MAP_GPIOIntEnable(pin61.port, pin61.pin);
    MAP_UARTIntEnable(CONSOLE1, UART_INT_RX); //UART INTERRUPT PINS

    Message("\t\t****************************************************\n\r");
    Message("\t\t Press remote # keys to generate an interrupt\n\r");
    Message("\t\t****************************************************\n\r");
    Message("\n\n\n\r");

    int x = 0;
    int y = 0;


    fillScreen(0);

    while (1) {



        if(enter == 1){
            Report("%s\n\r",letterArr);
            int i;
            for(i = 0; i < strlen(letterArr); i++){
                UartPutChar(letterArr[i]);
            }
            if(UART_flag == 1 && strlen(letterArr) > 0){
                Message("got something \n\r");
                cCharacter = UartGetChar();
            }

            enter = 0;
            memset(letterArr, 0, 80);
        }

        if(gpioTimeCount >= 300){
            strncat(letterArr, &letter, 1);

            if(num != 1){
                x += 6;
            }

            if(x > 124){
                x = 6;
                y += 8;
            }
            buttCount = 0;
            matchFound = 0;
        }

        if(buttCount > 2 ){
            if((num == 7 || num == 8) && buttCount < 4){
                buttCount = 3;
            }
            else{
                buttCount = 0;
            }
        }
        if(gpioTimeCount > 38 && gpioTimeCount < 300 && matchFound == 1){
            buttCount++;
        }


        if(gpioTimeCount > 20){
            // remove the first and last char for a stupid yet unknown reason
            if (gpioArr[0] == '1'){
                memmove(gpioArr, gpioArr+1, strlen(gpioArr));
            }
            gpioArr[strlen(gpioArr)-1] = '\0';

            // print the pressed button :)
            if(strcmp(gpioArr,ZERO) == 0){  //space
                num = 10;
                Message("You pressed ZERO\n\r");
                drawChar(x,y,32,GREEN,0,1);
                letter = ' ';
            }
            else if(strcmp(gpioArr,ONE) == 0){  //?!,.
                num = 1;
                matchFound = 1;
                Message("You pressed ONE\n\r");
                if(numColor == 1){
                    color = RED;
                }
                else if(numColor == 2){
                    color = BLUE;
                }
                else if(numColor == 3){
                    color = YELLOW;
                }
                else if(numColor == 4){
                    color = MAGENTA;
                }
                else if(numColor == 5){
                    color = GREEN;
                }
                else{
                    color = CYAN;
                }
                fillRect(x,y,5,7,color);
                numColor++;
                if(numColor > 5){
                    numColor = 0;
                }
            }
            else if(strcmp(gpioArr,TWO) == 0){  //ABC
                num = 2;
                matchFound = 1;
                Message("You pressed TWO\n\r");
                if(buttCount == 1){
                    drawChar(x,y,'B',color,0,1);
                    letter = 'B';
                }
                else if(buttCount == 2){
                    drawChar(x,y,'C',color,0,1);
                    letter = 'C';
                }
                else{
                    drawChar(x,y,'A',color,0,1);
                    letter = 'A';
                }

            }
            else if(strcmp(gpioArr,THREE) == 0){  //DEF
                num = 3;
                matchFound = 1;
                Message("You pressed THREE\n\r");
                if(buttCount == 1){
                    drawChar(x,y,'E',color,0,1);
                    letter = 'E';
                }
                else if(buttCount == 2){
                    drawChar(x,y,'F',color,0,1);
                    letter = 'F';
                }
                else{
                    drawChar(x,y,'D',color,0,1);
                    letter = 'D';
                }
            }
            else if(strcmp(gpioArr,FOUR) == 0){  //GHI
                num = 4;
                matchFound = 1;
                Message("You pressed FOUR\n\r");
                if(buttCount == 1){
                    drawChar(x,y,'H',color,0,1);
                    letter = 'H';
                }
                else if(buttCount == 2){
                    drawChar(x,y,'I',color,0,1);
                    letter = 'I';
                }
                else{
                    drawChar(x,y,'G',color,0,1);
                    letter = 'G';
                }
            }
            else if(strcmp(gpioArr,FIVE) == 0){  //JKL
                num = 5;
                matchFound = 1;
                Message("You pressed FIVE\n\r");
                if(buttCount == 1){
                    drawChar(x,y,'K',color,0,1);
                    letter = 'K';
                }
                else if(buttCount == 2){
                    drawChar(x,y,'L',color,0,1);
                    letter = 'L';
                }
                else{
                    drawChar(x,y,'J',color,0,1);
                    letter = 'J';
                }
            }
            else if(strcmp(gpioArr,SIX) == 0){  //MNO
                num = 6;
                matchFound = 1;
                Message("You pressed SIX\n\r");
                if(buttCount == 1){
                    drawChar(x,y,'N',color,0,1);
                    letter = 'N';
                }
                else if(buttCount == 2){
                    drawChar(x,y,'O',color,0,1);
                    letter = 'O';
                }
                else{
                    drawChar(x,y,'M',color,0,1);
                    letter = 'M';
                }
            }
            else if(strcmp(gpioArr,SEVEN) == 0){  //PQRS
                num = 7;
                matchFound = 1;
                num = 7;
                Message("You pressed SEVEN\n\r");
                if(buttCount == 1){
                    drawChar(x,y,'Q',color,0,1);
                    letter = 'Q';
                }
                else if(buttCount == 2){
                    drawChar(x,y,'R',color,0,1);
                    letter = 'R';
                }
                else if(buttCount == 3){
                    drawChar(x,y,'S',color,0,1);
                    letter = 'S';
                }
                else{
                    drawChar(x,y,'P',color,0,1);
                    letter = 'P';
                }
            }
            else if(strcmp(gpioArr,EIGHT) == 0){  //TUV
                num = 8;
                matchFound = 1;
                Message("You pressed EIGHT\n\r");
                if(buttCount == 1){
                    drawChar(x,y,'U',color,0,1);
                    letter = 'U';
                }
                else if(buttCount == 2){
                    drawChar(x,y,'V',color,0,1);
                    letter = 'V';
                }
                else{
                    drawChar(x,y,'T',color,0,1);
                    letter = 'T';
                }
            }
            else if(strcmp(gpioArr,NINE) == 0){  //WXYZ
                num = 9;
                matchFound = 1;
                num = 8;
                Message("You pressed NINE\n\r");
                if(buttCount == 1){
                    drawChar(x,y,'X',color,0,1);
                    letter = 'X';
                }
                else if(buttCount == 2){
                    drawChar(x,y,'Y',color,0,1);
                    letter = 'Y';
                }
                else if(buttCount == 3){
                    drawChar(x,y,'Z',color,0,1);
                    letter = 'Z';
                }
                else{
                    drawChar(x,y,'W',color,0,1);
                    letter = 'W';
                }
            }
            else if(strcmp(gpioArr,MUTE) == 0){   //delete char
                num = 11;
                matchFound = 1;
                Message("You pressed MUTE / DELETE\n\r");
                x -= 6;
                if(x < 0){
                    x = 0;
                    y -= 8;
                }
                if(y < 0){
                    y = 0;
                }
                fillRect(x,y,5,7,BLACK);
                letterArr[strlen(letterArr)-1] = '\0';

            }
            else if(strcmp(gpioArr,LAST) == 0){
                num = 12;
                matchFound = 1;
                Message("You pressed LAST / ENTER\n\r");
                enter = 1;
            }
            else if(strcmp(gpioArr,POWER) == 0){
                matchFound = 1;
                Message("You pressed POWER\n\r");
                drawChar(38,50,'B',WHITE,0,3);
                drawChar(58,50,'Y',WHITE,0,3);
                drawChar(78,50,'E',WHITE,0,3);
                fillScreen(0);
                x = 0;
                y = 0;
                color = GREEN;
                memset(letterArr, 0, 80);
            }



            // clear the array
            memset(gpioArr, 0, 26);

            if(y > 127){
                y = 0;
            }
        }

        while ((pin61_intflag==0)) {;}
        if (pin61_intflag) {
            pin61_intflag=0;  // clear flag
        }
    }
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
