//*****************************************************************************
//
// Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
//
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//    Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//
//    Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the
//    distribution.
//
//    Neither the name of Texas Instruments Incorporated nor the names of
//    its contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
//  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//*****************************************************************************

//*****************************************************************************
//
// Application Name     - SPI Demo
// Application Overview - The demo application focuses on showing the required
//                        initialization sequence to enable the CC3200 SPI
//                        module in full duplex 4-wire master and slave mode(s).
//
//*****************************************************************************


//*****************************************************************************
//
//! \addtogroup SPI_Demo
//! @{
//
//*****************************************************************************

// Standard includes
#include <string.h>

// Driverlib includes
#include "hw_types.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "hw_ints.h"
#include "spi.h"
#include "rom.h"
#include "rom_map.h"
#include "utils.h"
#include "prcm.h"
#include "uart.h"
#include "interrupt.h"

// Common interface includes
#include "i2c_if.h"
#include "uart_if.h"
#include "pin_mux_config.h"

#include "Adafruit_GFX.h"
#include "Adafruit_SSD1351.h"
#include "glcdfont.h"


#define APPLICATION_VERSION     "1.4.0"
//*****************************************************************************
//
// Application Master/Slave mode selector macro
//
// MASTER_MODE = 1 : Application in master mode
// MASTER_MODE = 0 : Application in slave mode
//
//*****************************************************************************
#define MASTER_MODE      1

#define SPI_IF_BIT_RATE  100000
#define TR_BUFF_SIZE     100

#define MASTER_MSG       "This is CC3200 SPI Master Application\n\r"
#define SLAVE_MSG        "This is CC3200 SPI Slave Application\n\r"


#define BLACK           0x0000
#define BLUE            0x001F
#define GREEN           0x07E0
#define CYAN            0x07FF
#define RED             0xF800
#define MAGENTA         0xF81F
#define YELLOW          0xFFE0
#define WHITE           0xFFFF

//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************
//static unsigned char g_ucTxBuff[TR_BUFF_SIZE];
//static unsigned char g_ucRxBuff[TR_BUFF_SIZE];
//static unsigned char ucTxBuffNdx;
//static unsigned char ucRxBuffNdx;

#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif
//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************



//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************
static void
BoardInit(void)
{
/* In case of TI-RTOS vector table is initialize by OS itself */
#ifndef USE_TIRTOS
  //
  // Set vector table base
  //
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    //
    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}
//*****************************************************************************
//
//! Main function for spi demo application
//!
//! \param none
//!
//! \return None.
//
//****************************************************************************

void map(){
    drawRoundRect(51,54,7,20,2,BLUE);
    drawRoundRect(74,54,7,20,2,BLUE);

    //center left
    drawRoundRect(35,20,7,36,2,BLUE);
//    drawRoundRect(35,54,16,3,2,BLUE);

    //center right
    drawRoundRect(88,20,7,36,2,BLUE);
//    drawRoundRect(79,54,16,3,2,BLUE);

    //center top
    drawRoundRect(62,0,7,30,2,BLUE);

    //top left
    drawRoundRect(0,0,3,31,2,BLUE);
    drawRoundRect(0,0,128,3,2,BLUE);

    //top right
    drawRoundRect(125,0,3,31,2,BLUE);

    //bottom left
    drawRoundRect(0,71,128,3,2,BLUE);

    //entrance left
    drawRoundRect(-2,28,15,3,2,BLUE);
    drawRoundRect(10,28,3,28,2,BLUE);
    drawRoundRect(-2,53,15,3,2,BLUE);

    //entrance right
    drawRoundRect(114,28,15,3,2,BLUE);
    drawRoundRect(114,28,3,28,2,BLUE);
    drawRoundRect(114,53,15,3,2,BLUE);
}

void coins(){
    fillCircle(10,10,1,WHITE);
    fillCircle(24,10,1,WHITE);
    fillCircle(38,10,1,WHITE);
    fillCircle(52,10,1,WHITE);
    fillCircle(52,24,1,WHITE);
    fillCircle(52,38,1,WHITE);

    fillCircle(65,38,1,WHITE);

    fillCircle(120,10,1,WHITE);
    fillCircle(106,10,1,WHITE);
    fillCircle(92,10,1,WHITE);
    fillCircle(78,10,1,WHITE);
    fillCircle(78,24,1,WHITE);
    fillCircle(78,38,1,WHITE);

    fillCircle(10,63,1,WHITE);
    fillCircle(24,63,1,WHITE);
    fillCircle(38,63,1,WHITE);

    fillCircle(120,63,1,WHITE);
    fillCircle(106,63,1,WHITE);
    fillCircle(92,63,1,WHITE);

    fillCircle(24,24,1,WHITE);
    fillCircle(24,38,1,WHITE);
    fillCircle(24,50,1,WHITE);

    fillCircle(106,24,1,WHITE);
    fillCircle(106,38,1,WHITE);
    fillCircle(106,50,1,WHITE);
}

void main()

{
    Message("In main( )\n\r");
    //
    // Initialize Board configurations
    //
    BoardInit();

    //
    // Muxing UART and SPI lines.
    //
    PinMuxConfig();

    //
    // Enable the SPI module clock.
    //
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI,PRCM_RUN_MODE_CLK);

    //
    // Initialising the Terminal.
    //
    InitTerm();

    I2C_IF_Open(I2C_MASTER_MODE_FST);

    //
    // Clearing the Terminal.
    //
    ClearTerm();

    //
    // Display the Banner
    //
    Message("\n\n\n\r");
    Message("\t\t   ********************************************\n\r");
    Message("\t\t        CC3200 SPI Demo Application  \n\r");
    Message("\t\t   ********************************************\n\r");
    Message("\n\n\n\r");

    //
    // Enable the SPI module clock
    //
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI,PRCM_RUN_MODE_CLK);

    // Reset the peripheral
    //
    MAP_PRCMPeripheralReset(PRCM_GSPI);

    //Reset SPI
    MAP_SPIReset(GSPI_BASE);

    //Configure SPI
    MAP_SPIConfigSetExpClk(GSPI_BASE,MAP_PRCMPeripheralClockGet(PRCM_GSPI),
                           SPI_IF_BIT_RATE,SPI_MODE_MASTER,SPI_SUB_MODE_0,
                           (SPI_SW_CTRL_CS |
                                   SPI_4PIN_MODE |
                                   SPI_TURBO_OFF |
                                   SPI_CS_ACTIVEHIGH |
                                   SPI_WL_8));

    //Enable SPI for communication.
    MAP_SPIEnable(GSPI_BASE);

    //initializes the OLED screen
    Adafruit_Init();

    unsigned char ucRegOffsetX = 0x3;
    unsigned char ucRegOffsetY = 0x5;
    unsigned char aucRdDataBufX[256];
    unsigned char aucRdDataBufY[256];
    unsigned char ucDevAddr = 0x18;

    int x = 66;
    int y = 64;
    int delay = 4;
    fillScreen(0);

    map();
    coins();

    while(1){
        fillCircle(x,y,4,YELLOW);
        I2C_IF_Write(ucDevAddr,&ucRegOffsetX,1,0);
        I2C_IF_Read(ucDevAddr, &aucRdDataBufX[0], 1);

        I2C_IF_Write(ucDevAddr,&ucRegOffsetY,1,0);
        I2C_IF_Read(ucDevAddr, &aucRdDataBufY[0], 1);

        float bufx = (float)((signed char)aucRdDataBufX[0]) / delay;
        float bufy = (float)((signed char)aucRdDataBufY[0]) / delay;

        int dx = bufx*-1;

        int dy = bufy;

        unsigned char oldx = x;

        unsigned char oldy = y;

        x = x + dx;
        y = y + dy;

        int lifex = 10;
        int lifey = 100;

        Report("x: %d, y: %d \n\r", x, y);


        //left edge.
        if(y < 60 && x < 17 && y > 23){
            if(y < 60 && y > 40){
                y = 60;
                fillCircle(10,lifey,2,RED);
            }
            if(y > 23 && y < 40){
                y = 23;
                fillCircle(20,lifey,2,RED);
            }
        }

        //right edge.
        if(y < 60 && x > 109 && y > 23){
            if(y < 60 && y > 40){
                y = 60;
                fillCircle(30,lifey,2,RED);
            }
            if(y > 23 && y < 40){
                y = 23;
                fillCircle(40,lifey,2,RED);
            }
        }

        //center left
        if(x < 62 && x > 43 && y > 48 && y < 70){
            if(x < 62 && x > 55 && y > 48 && y < 70){
                x = 62;
                fillCircle(50,lifey,2,RED);
            }
            if(x > 43 && x < 55 && y > 48 && y < 70){
                x = 43;
                fillCircle(60,lifey,2,RED);
            }
        }

        //center right
        if(x < 86 && x > 69 && y > 48 && y < 70){
            if(x < 86 && x > 78 && y > 48 && y < 70){
                x = 86;
                fillCircle(70,lifey,2,RED);
            }
            if(x > 69 && x < 78 && y > 48 && y < 70){
                x = 69;
                fillCircle(80,lifey,2,RED);
            }
        }

        //middle left
        if(x < 47 && x > 30 && y > 15 && y < 60){
            if(x < 47 && x > 39 && y > 15 && y < 60){
                x = 47;
                fillCircle(90,lifey,2,RED);
            }
            if(x > 30 && x < 39 && y > 15 && y < 60){
                x = 30;
                fillCircle(100,lifey,2,RED);
            }
        }

        //middle right
        if(x < 100 && x > 83 && y > 15 && y < 60){
            if(x < 100 && x > 92 && y > 15 && y < 60){
                x = 100;
                fillCircle(110,lifey,2,RED);
            }
            if(x > 83 && x < 92 && y > 15 && y < 60){
                x = 83;
                fillCircle(120,lifey,2,RED);
            }
        }

        //middle
        if(x < 74 && x > 57 && y > 0 && y < 35){
            if(x < 74 && x > 66 && y > 0 && y < 35){
                x = 74;
                fillCircle(lifex,lifey,2,RED);
            }
            if(x > 57 && x < 66 && y > 0 && y < 35){
                x = 57;
                fillCircle(lifex,lifey,2,RED);
            }
        }

        //wall
        if(x > 120){
            x = 120;
            fillCircle(10,lifey,2,RED);
        }
        if(x < 7){
            x = 7;
            fillCircle(20,lifey,2,RED);
        }
        if(y > 66){
            y = 66;
            fillCircle(30,lifey,2,RED);
        }
        if(y < 7){
            y = 7;
            fillCircle(40,lifey,2,RED);
        }


        fillCircle(oldx,oldy, 4, BLACK);
    }
}

